# Completed Tasks
- [x] Multiplayer
- [x] Dictionary
- [x] Playing on all boards
- [x] Parallelism 
- [x] Respect Timeout flag